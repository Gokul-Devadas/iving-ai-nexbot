# Living-AI Nexbot

A single-page, voice-controlled humanoid robot landing page with a 3D Spline robot background, dark/light themes, an animated wave, and a demo voice assistant.

**Live demo:** https://YOUR-USERNAME.github.io/YOUR-REPO/

## Features
- Full-screen 3D robot (Spline) as the background
- Power button, menu tabs, animated wave, dark and light theme toggle
- AI tab with *Voice link* (speech recognition) and *Vitals* (spoken male voice)
- Responsive layout for desktop, tablet and phone
- Runs entirely in the browser: no server, no database, no API keys

## Demo mode
Replies are pre-written in the `FAQ` list inside `index.html`. No questions leave the browser. Voice input works in Chrome and Edge over HTTPS (GitHub Pages is HTTPS).

## Run locally
Open `index.html` in Chrome or Edge, or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Credits
3D robot scene by its Spline author, embedded from my.spline.design.
